# Dinner_Spinner
Ever been lost on where to go out to eat?


Dinner Spinner is a location based app that will give users a randomized list of restaurants within your desired radius and 
restaurant prefences(rating, price, type of food, etc.). User prefences and info can be stored in a database via sequalize.
We plan on using google maps API and maybe something like Yelp for the restaurant listings.
